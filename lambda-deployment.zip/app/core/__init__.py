"""Core utilities and configuration."""
