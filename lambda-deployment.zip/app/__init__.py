"""Spool Exercise Service - Adaptive exercise generation and evaluation."""

__version__ = "1.0.0"
