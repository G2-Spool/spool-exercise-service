"""Exercise generation modules."""
