"""Data models for Exercise Service."""
