"""API routers for exercise service."""
