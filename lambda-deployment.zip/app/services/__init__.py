"""Services module for exercise service."""
