"""Resources package for the exercise service."""
